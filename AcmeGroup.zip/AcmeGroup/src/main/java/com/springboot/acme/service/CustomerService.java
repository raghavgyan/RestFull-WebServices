package com.springboot.acme.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.acme.beans.Customer;
import com.springboot.acme.beans.CustomerOrderDetails;
import com.springboot.acme.repository.AbstractCustomerDao;
import com.springboot.acme.repository.AbstractCustomerOrderDao;

@Service
public class CustomerService implements AbsttractCustomerService{

	@Autowired
	AbstractCustomerDao dao;
	
	@Autowired
	AbstractCustomerOrderDao orderDao;
	
	@Override
	public List<Customer> getCustomers() {
		
		 return dao.getAllCustomer();
	}

	@Override
	public Customer getCustById(int id) {
		
		return dao.getCustmerById(id);
	}

	@Override
	public int updateCustCity(String city, int cid) {
		 return dao.updateCustomerCity(city, cid);
	}

	@Override
	public int delCust(int cid) {
		
		return dao.deleteCustomer(cid);
	}

	@Override
	public List<CustomerOrderDetails> getCustOrders() {
		return orderDao.getAllCustOrders();
	}

}
