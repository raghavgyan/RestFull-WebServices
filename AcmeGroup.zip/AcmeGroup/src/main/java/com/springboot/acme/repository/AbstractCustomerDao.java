package com.springboot.acme.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.springboot.acme.beans.Customer;
import com.springboot.acme.beans.CustomerOrderDetails;

public interface AbstractCustomerDao extends JpaRepository<Customer, Integer>{
	
	@Query("from Customer")
	public List<Customer> getAllCustomer();
	
	@Query("from Customer where cid =:cid ")
	public Customer getCustmerById(int cid);
	
		
	@Modifying
	@Transactional
	@Query(value = "update Customer set city=:city where cid=:cid",nativeQuery = true)
	public int updateCustomerCity(String city,int cid);
	
	@Modifying
	@Transactional
	@Query(value = "delete from Customer where cid=:cid",nativeQuery = true)
	public int deleteCustomer(int cid);

}
