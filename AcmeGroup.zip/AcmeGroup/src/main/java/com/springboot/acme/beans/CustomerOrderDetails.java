package com.springboot.acme.beans;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class CustomerOrderDetails {
	
	@Id
	private int cid;
	private String cname;
	private String prod_name;
	private int price;
	
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getProd_name() {
		return prod_name;
	}
	public void setProd_name(String prod_name) {
		this.prod_name = prod_name;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	

}
