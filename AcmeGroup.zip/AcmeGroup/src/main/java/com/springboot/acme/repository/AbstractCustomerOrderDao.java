package com.springboot.acme.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.springboot.acme.beans.CustomerOrderDetails;

public interface AbstractCustomerOrderDao extends JpaRepository<CustomerOrderDetails, Integer>{
	
	@Query(value = "select cid,cname,prod_name,price from Customer c join CustOrder o on c.order_id=o.order_id",nativeQuery = true)
	public List<CustomerOrderDetails> getAllCustOrders();

}
