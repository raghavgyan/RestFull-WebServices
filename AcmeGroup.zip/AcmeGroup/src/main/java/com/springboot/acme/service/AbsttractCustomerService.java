package com.springboot.acme.service;

import java.util.List;

import com.springboot.acme.beans.Customer;
import com.springboot.acme.beans.CustomerOrderDetails;

public interface AbsttractCustomerService {
	
	public List<Customer> getCustomers();
	
	public Customer getCustById(int id);
	
	public int updateCustCity(String city,int cid);
	
	public int delCust(int cid);
	
	public List<CustomerOrderDetails> getCustOrders();

}
