package com.springboot.acme.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.acme.beans.Customer;
import com.springboot.acme.beans.CustomerOrderDetails;
import com.springboot.acme.service.AbsttractCustomerService;



@RestController
@RequestMapping("/cust")
public class RequestController {
	
	@Autowired
	AbsttractCustomerService service;
	
	@RequestMapping("/")
	public List<Customer> getAllCustomerData()
	{
		return service.getCustomers();
	}
	
	@RequestMapping("/custById/{id}")
	public Customer searchCustomer(@PathVariable("id") int cid)
	{
		return service.getCustById(cid);
	}
	
	@RequestMapping("/orderDetails")
	public List<CustomerOrderDetails> getCompleteOrderDetails()
	{
		 return service.getCustOrders();
	}
	
	@RequestMapping("/updCity/{cid}/{city}")
	public String updateCustCity(@PathVariable("cid") int cid,@PathVariable("city") String city)
	{
		if(service.updateCustCity(city, cid) > 0)
		{ 
			return "successfully updated the city to "+city;
		}
		else
		{
			return "Nothing updated";
		}
	}
	
	
}
